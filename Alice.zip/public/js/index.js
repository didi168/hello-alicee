// nav bar open function
function openMenu(){
    var nav=document.querySelector("nav");
      var bar=document.querySelector("#bar");
      var x=document.querySelector("#x");
  
      nav.style.display="flex"
      bar.style.display="none"
      x.style.display="flex"
  }
  // nav menu close function 
  function closeMenu(){
    var nav=document.querySelector("nav");
      var bar=document.querySelector("#bar");
      var x=document.querySelector("#x");
  
   nav.style.display="none"
   bar.style.display="flex"
   x.style.display="none"
  }
  

  // nav bar open function
  function openMenu(){
    var nav=document.querySelector("nav");
      var bar=document.querySelector("#bar");
      var x=document.querySelector("#x");
  
      nav.style.display="flex"
      bar.style.display="none"
      x.style.display="flex"
  }
  // nav menu close function 
  function closeMenu(){
    var nav=document.querySelector("nav");
      var bar=document.querySelector("#bar");
      var x=document.querySelector("#x");
  
   nav.style.display="none"
   bar.style.display="flex"
   x.style.display="none"
  }